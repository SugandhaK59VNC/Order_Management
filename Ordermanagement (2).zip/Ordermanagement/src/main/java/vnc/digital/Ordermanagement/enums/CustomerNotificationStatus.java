package vnc.digital.Ordermanagement.enums;

public enum CustomerNotificationStatus {
    Sent;
}
