package vnc.digital.Ordermanagement.model;

import vnc.digital.Ordermanagement.enums.UnitOfMeasure;

public class OrderItems {
    private String name;
    private String currency;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public float getPricePerUnit() {
        return pricePerUnit;
    }

    public void setPricePerUnit(float pricePerUnit) {
        this.pricePerUnit = pricePerUnit;
    }

    public UnitOfMeasure getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public void setUnitOfMeasure(UnitOfMeasure unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getOrderItemPrice() {
        return orderItemPrice;
    }

    public void setOrderItemPrice(float orderItemPrice) {
        this.orderItemPrice = orderItemPrice;
    }

    private float pricePerUnit;
    private UnitOfMeasure unitOfMeasure;
    private String brandName;
    private int quantity;
    private float orderItemPrice;

}
