package vnc.digital.Ordermanagement.enums;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum StatusResponse {
    SUCCESS(10000, "SUCCESS"),

    FAIL(10001, "FAIL"),

    UNKNOWN_ERROR_OCCURRED(10002, "UNKNOWN_ERROR_OCCURRED"),

    INVALID_REQUEST_PARAMETER(10003, "INVALID_REQUEST_PARAMETER"),

    INTERNAL_SERVER_ERROR(10005, "INTERNAL_SERVER_ERROR"),

    INVALID_REQUEST(10006, "INVALID_REQUEST"),

    BAD_REQUEST(10007, "BAD_REQUEST"),

    NULL_POINTER_EXCEPTION(10008, "NULL_POINTER_EXCEPTION"),

    LOGIN_SUCCESS(20000,"USER_LOGIN_SUCCESSFULLY"),
    LOGIN_FAIL(20001,"USER_LOGIN_FAIL"),
    USER_SUCCESSFULLY_REGISTERED(20003,"USER_SUCCESSFULLY_REGISTERED"),
    USER_ALREADY_EXIST(20002,"USER_ALREADY_EXISTS"),
    USER_ALREADY_LOGGED_IN(20004,"USER_ALREADY_LOGGED_IN"),
    USER_DOES_NOT_EXIST(20007,"USER_DOES_NOT_EXIST"),
    ;

    private final Integer code;
    private final String reason;

    private static final Map<Integer, StatusResponse> RESPONSE_STATUS_CODE_MAP = Arrays
            .stream(StatusResponse.values())
            .collect(Collectors.toMap(StatusResponse::getCode, Function.identity()));


    StatusResponse(Integer code, String reason) {
        this.code = code;
        this.reason = reason;
    }

    public static StatusResponse valueOf(int value) {
        if (RESPONSE_STATUS_CODE_MAP.containsKey(value)) {
            return RESPONSE_STATUS_CODE_MAP.get(value);
        }
        throw new IllegalArgumentException("No matching constant for [" + value + "]");
    }

    public Integer getCode() {
        return code;
    }

    public String getReason() {
        return reason;
    }

    @Override
    public String toString() {
        return "StatusResponse{" +
                "code=" + code +
                ", reason='" + reason + '\'' +
                '}';
    }
}
