package vnc.digital.Ordermanagement.exception;

import vnc.digital.Ordermanagement.enums.StatusResponse;

public class ExceptionHandler extends RuntimeException {
    private final Integer code;
    private final String message;

    public ExceptionHandler(StatusResponse statusCode) {
        super();
        this.code = statusCode.getCode();
        this.message = statusCode.getReason();
    }
    public Integer getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
