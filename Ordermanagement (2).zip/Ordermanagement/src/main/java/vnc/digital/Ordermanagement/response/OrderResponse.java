package vnc.digital.Ordermanagement.response;

import org.springframework.data.annotation.Id;
import vnc.digital.Ordermanagement.enums.BusinessNotificationStatus;
import vnc.digital.Ordermanagement.enums.CustomerNotificationStatus;
import vnc.digital.Ordermanagement.enums.OrderStatus;
import vnc.digital.Ordermanagement.model.Location;
import vnc.digital.Ordermanagement.model.OrderItems;

import java.sql.Timestamp;

public class OrderResponse {
    @Id
    private String id;
    private Location location;
    private OrderItems orderItems;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public OrderItems getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(OrderItems orderItems) {
        this.orderItems = orderItems;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderEmailAddress() {
        return orderEmailAddress;
    }

    public void setOrderEmailAddress(String orderEmailAddress) {
        this.orderEmailAddress = orderEmailAddress;
    }

    public String getOrderPhoneNum() {
        return orderPhoneNum;
    }

    public void setOrderPhoneNum(String orderPhoneNum) {
        this.orderPhoneNum = orderPhoneNum;
    }

    public Timestamp getLastUpdatedTimeStamp() {
        return lastUpdatedTimeStamp;
    }

    public void setLastUpdatedTimeStamp(Timestamp lastUpdatedTimeStamp) {
        this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
    }

    public Timestamp getCreatedTimeStamp() {
        return createdTimeStamp;
    }

    public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
        this.createdTimeStamp = createdTimeStamp;
    }

    public BusinessNotificationStatus getBusinessNotificationStatus() {
        return businessNotificationStatus;
    }

    public void setBusinessNotificationStatus(BusinessNotificationStatus businessNotificationStatus) {
        this.businessNotificationStatus = businessNotificationStatus;
    }

    public String getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(String orderAmount) {
        this.orderAmount = orderAmount;
    }

    public String getOrderFirstName() {
        return orderFirstName;
    }

    public void setOrderFirstName(String orderFirstName) {
        this.orderFirstName = orderFirstName;
    }

    public String getOrderLastName() {
        return orderLastName;
    }

    public void setOrderLastName(String orderLastName) {
        this.orderLastName = orderLastName;
    }

    public CustomerNotificationStatus getCustomerNotificationStatus() {
        return customerNotificationStatus;
    }

    public void setCustomerNotificationStatus(CustomerNotificationStatus customerNotificationStatus) {
        this.customerNotificationStatus = customerNotificationStatus;
    }

    //private String customerid;
    //private String Businessid;
    private OrderStatus orderStatus;
    private String orderEmailAddress;
    private String orderPhoneNum;
    private Timestamp lastUpdatedTimeStamp;
    private Timestamp createdTimeStamp;
    private BusinessNotificationStatus businessNotificationStatus;
    private String orderAmount;
    private String orderFirstName;
    private String orderLastName;
    private CustomerNotificationStatus customerNotificationStatus;
}
