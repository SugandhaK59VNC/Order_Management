package vnc.digital.Ordermanagement.service;

import org.springframework.stereotype.Service;

@Service
public interface OrderService {
}
