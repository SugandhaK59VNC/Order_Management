package vnc.digital.Ordermanagement.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import vnc.digital.Ordermanagement.model.Orders;

public interface OrderRepository extends MongoRepository<Orders,String> {
}
