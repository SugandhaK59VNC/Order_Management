package vnc.digital.Ordermanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import vnc.digital.Ordermanagement.repository.OrderRepository;

public class OrderServiceImp implements OrderService{
    @Autowired
    private OrderRepository orderRepository;

}
