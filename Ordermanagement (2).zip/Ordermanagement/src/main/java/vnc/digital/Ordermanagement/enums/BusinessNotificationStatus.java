package vnc.digital.Ordermanagement.enums;

public enum BusinessNotificationStatus {
    Sent;
}
