package vnc.digital.Ordermanagement.enums;

public enum UnitOfMeasure {
    items,kgs,lts,gms,ml;
}
