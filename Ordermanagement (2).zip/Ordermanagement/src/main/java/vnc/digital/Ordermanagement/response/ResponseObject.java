package vnc.digital.Ordermanagement.response;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import vnc.digital.Ordermanagement.enums.StatusResponse;


@JsonInclude(JsonInclude.Include.NON_NULL)

public class ResponseObject<T> {

    private ResponseStatus status;

    private T response;

    public ResponseObject() {
        super();
    }

    public ResponseObject(StatusResponse statusCode) {
        this.status = new ResponseStatus(statusCode);
    }

    public ResponseObject(StatusResponse statusCode, String actualErrorMessage) {
        this.status = new ResponseStatus(statusCode, actualErrorMessage);
    }

    public ResponseObject(StatusResponse statusCode, Map<String, String> errors) {
        this.status = new ResponseStatus(statusCode, errors);
    }

    public ResponseObject(ResponseStatus status) {
        this.status = status;
    }

    public ResponseObject(T response, StatusResponse statusCode) {
        this.response = response;
        this.status = new ResponseStatus(statusCode);
    }

    public ResponseStatus getStatus() {
        return status;
    }

    public void setStatus(ResponseStatus status) {
        this.status = status;
    }

    public T getResponse() {
        return response;
    }

    public void setResponse(T response) {
        this.response = response;
    }

    public static <T> ResponseObject<T> success(T response) {
        return new ResponseObject<>(response, StatusResponse.SUCCESS);
    }


}
